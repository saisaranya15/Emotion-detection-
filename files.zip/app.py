import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.pipeline import Pipeline
import warnings

warnings.filterwarnings('ignore')

# -------------------------------------------
# Streamlit Page Design
# -------------------------------------------

st.markdown("""
    <h1 style='color:white; text-align:center;'>Emotion Detection using Machine Learning</h1>
""", unsafe_allow_html=True)

# -------------------------------------------
# 1. Business and Data Understanding Section
# -------------------------------------------
st.header("📌 1. Business and Data Understanding")

# a) Business Problem
st.subheader("a) Business Problem of Emotion Detection Using ML")
st.write("""
The Emotion Detection System aims to analyze human emotions from text data in customer interactions, 
improve decision-making, and monitor sentiment across various applications such as customer service.
""")

# b) Business Objective
st.subheader("b) Business Objective")
st.write("""
The goal of this project is to develop an Emotion Detection System that accurately detects 
and analyzes human emotions from multimodal data sources.
""")

# c) Business Constraints
st.subheader("c) Business Constraints")
st.write("""
- **Data Privacy & Security**  
- **Language & Emoji Variations**  
- **Accuracy & Context Awareness**  
- **Scalability**  
- **Real-Time Processing**  
""")

# d) Data Understanding
st.subheader("d) Data Understanding")
st.write("""
Understanding the data is crucial for building an effective emotion detection system. The dataset used 
for emotion detection typically consists of textual, speech, facial expression, or physiological data, 
depending on the application.

**Types of Data Sources:**
- Text Data
- Speech Data

**Challenges in Data Understanding:**
- Noisy Data
- Data Labeling
- Multimodal Complexity
- Class Imbalance
""")

# -------------------------------------------
# 2. Load Dataset and Preprocess
# -------------------------------------------

file_path = "combined_emotion.csv"

try:
    df = pd.read_csv(file_path)
except FileNotFoundError:
    st.error("Error: combined_emotion.csv not found. Please upload the file.")
    st.stop()

# Drop missing values and exclude 'others'
df = df.dropna()
df = df[df['emotion'] != 'others']
# -------------------------------------------
# 3. Model Training Section
# -------------------------------------------

#st.header("🤖 3. Model Training")

# Splitting and Training
X = df['sentence']
y = df['emotion']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Pipeline with CountVectorizer and Naive Bayes
model = Pipeline([
    ("Vectorizer", CountVectorizer(stop_words='english', lowercase=True)),
    ("Classifier", MultinomialNB(alpha=1.0))
])

model.fit(X_train, y_train)

# -------------------------------------------
# 4. Real-Time Emotion Detection Section
# -------------------------------------------

st.header("Real-Time Emotion Detection")

# Emoji mapping including 'neutral'
emoji_dict = {
    'sad': '😔',
    'joy': '😊',
    'love': '❤️',
    'anger': '😡',
    'fear': '😨',
    'surprise': '😲',
    'neutral': '😐'
}

# User Input
user_input = st.text_area("Enter your sentence here to detect emotion:")

if st.button("Detect Emotion"):
    if user_input.strip():
        # Prediction
        prediction = model.predict([user_input])[0]
        emoji = emoji_dict.get(prediction, "❓")  # Default emoji if not found

        # Display Prediction
        st.write(f"###  Predicted Emotion: *{prediction.capitalize()}* {emoji}")
        #st.markdown(f"<h1 style='text-align:center;'>{emoji}</h1>", unsafe_allow_html=True)
    else:
        st.warning("⚠️ Please enter a sentence to analyze.")

